package TicTacToe;

import java.io.File;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.print("Введите 9-значное число, состоящее из цифр от 0 до 3: ");
        String ticTacString = scan.nextLine();

        TicTacPosition ticTacPosition = new TicTacPosition();

        String fileName = String.join("\\",
                String.join("\\",new File("").getAbsolutePath(),
                        "\\src\\TicTacToe\\File\\TicTacToe.txt"));
        FileOperation fileOperation = new FileOperation(fileName);

        fileOperation.savePosition(ticTacPosition.ticTacPositionConvert(ticTacString));

    }



}
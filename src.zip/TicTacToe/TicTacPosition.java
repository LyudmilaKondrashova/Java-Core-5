package TicTacToe;

public class TicTacPosition {

    private int position;

    public TicTacPosition() {

    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public byte[] ticTacPositionConvert(String positionString) {
        int position = 0;

        if (positionString.length() != 9) {
            throw new RuntimeException("Длина введенного числа не равна 9!");
        }

        try {
            position = Integer.parseInt(positionString);
        } catch (NumberFormatException e) {
            throw new RuntimeException("Введенная строка не является числом!");
        }

        for (int i = 0; i < 9; i++) {
            if (positionString.charAt(i) != '0' && positionString.charAt(i) != '1' &&
                    positionString.charAt(i) != '2' && positionString.charAt(i) != '3') {
                throw new RuntimeException("Введенное число содержит цифры, отличные от 0, 1, 2, 3!");
            }
        }

        return intToBytes(position);
    }

    public byte[] intToBytes(int position){
        byte[] bytes = new byte[3];
        int tempPos = position / 1_000_000;
        int s = 0xff;
        bytes[0] = (byte) (tempPos & s);
        position %= 1_000_000;
        tempPos = position / 1_000;
        bytes[1] = (byte) (tempPos & s);
        position %= 1_000;
        tempPos = position;
        bytes[2] = (byte) (tempPos & s);

        return bytes;
    }

}

package TicTacToe;

import java.io.*;

public class FileOperation {
    private String fileName;

    public FileOperation(String fileName) {
        this.fileName = fileName;
        try (FileWriter writer = new FileWriter(fileName, true)) {
            writer.flush();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    // Запись в файл
    public void savePosition(byte[] position) {

        try {
            createDataFile(fileName);
        } catch (IOException ex) {
            throw new RuntimeException(ex.getMessage());
        }
        try (FileOutputStream fos = new FileOutputStream(fileName)) {
            fos.write(position);
            fos.flush();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        System.out.println("Запись в файл прошла успешно!");
    }

    // Создание файла, если он отсутствует
    public void createDataFile(String fileName) throws IOException {
        File file = new File(fileName);
        boolean created = file.createNewFile();
    }

}

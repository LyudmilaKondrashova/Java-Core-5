package CopyFiles;

import java.io.File;

public class Main {

    public static void main(String[] args) {

        String sourceDir = String.join("\\",
                String.join("\\",new File("").getAbsolutePath(),
                        "\\src\\CopyFiles\\TestFiles\\"));
        String targetDir = String.join("\\", String.join("\\",
                sourceDir, "_backup\\"));

        FileOperation.copyWholeDirectory(sourceDir, targetDir);

    }

}
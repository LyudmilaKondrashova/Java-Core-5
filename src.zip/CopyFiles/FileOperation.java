package CopyFiles;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class FileOperation {

    public static void copyWholeDirectory(String sourceDir, String targetDir) {
        try {
            File sourceDirectory = new File(sourceDir);
            if (sourceDirectory.isDirectory()) {
                File[] listOfFiles = sourceDirectory.listFiles();
                if (listOfFiles.length == 0) { throw new RuntimeException("Каталог " + sourceDir + " пустой!"); }
                else {
                    File targetDirectory = new File(targetDir);
                    if (!targetDirectory.exists()) {
                        if (targetDirectory.mkdir()) {
                            System.out.println("Начато копирование содержимого из каталога " + sourceDir +
                                    " в каталог " + targetDir);
                            for (File file : listOfFiles) {
                                if (file.toPath() != targetDirectory.toPath()) {
                                    Files.copy(file.toPath(), targetDirectory.toPath().resolve(file.getName()),
                                            StandardCopyOption.REPLACE_EXISTING);
                                }
                            }
                            System.out.println("Копирование завершено успешно!");
                        } else {
                            throw new RuntimeException("Не удалось создать каталог " + sourceDir + "!");
                        }
                    } else {
                        throw new RuntimeException("Каталог " + targetDir + " уже существует! " +
                                "Удалите его и запустите программу снова!");
                    }
                }
            } else { throw new RuntimeException(sourceDir + " - это не каталог, а файл!"); }
        } catch (FileNotFoundException e) {
            System.out.println("Каталог " + sourceDir + " отсутствует!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
